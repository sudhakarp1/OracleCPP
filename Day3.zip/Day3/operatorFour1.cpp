
/*
*
*/
#include <iostream>
using std::cout;

class CComplex{
    double _real;
    double _imag;
public:
    CComplex():_real(0.0), _imag(0.0){}
    CComplex(double real, double imag):_real(real), _imag(imag){}

    friend CComplex AddCComplex(CComplex &obj1, CComplex &obj2){
        return CComplex(obj1._real+obj2._real , obj1._imag + obj2._imag);
    }
    friend std::ostream& operator<<(std::ostream &out, CComplex &obj){
        out<<obj._real<<(obj._imag>=0.0?"+": "") << obj._imag<<"i" ;
        return out;
    }
};
void Line(std::ostream &out){
    out<<"-----------------------------------\n";
}
int main(){
    CComplex c1;
    CComplex c2(10,30);
    CComplex c3(12,-24);
    cout<<c1<<"\n";
    cout<<c2<<"\n";
    cout<<c3<<"\n";
    Line(cout);
    CComplex c4 = AddCComplex(c2,c3);
    cout<<c4<<"\n";
    Line(cout);
}


