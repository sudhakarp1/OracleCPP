#include <iostream>
using std::cout;

class CA{
    int *ptr;
    int *count;
public:
    CA(int x=0):ptr(new int(x)),count(new int(1)) {
        cout<<"Object created...\n";
    }
    CA(const CA &par):ptr(par.ptr),count(par.count){//shallow copy
        *count = *count + 1; //keeping count of copies
       // cout<<"shallow copy...\n";
    }
    CA& operator=(const CA &rhs){//transfer ownership
        CA &temp = (const_cast<CA &>(rhs)); //removing the const
        std::swap(ptr, temp.ptr);
        std::swap(count, temp.count);
        return *this;
    }

    ~CA(){
        --*count;
        if (*count==0){
            cout<<"Object Resource freed...\n";
            delete ptr;
        }
    }
    void disp(){
        cout<<"Ptr: "<<ptr;
        if (ptr)
            cout<<"\t: *ptr: "<<*ptr<<'\t'<<"Count: "<<*count;
        else
            cout<<"\t:  ptr: null";
        cout<<"\n";
    }
};

int main(){
    CA ob1=10;
    CA ob2=20;
    ob1.disp();
    ob2.disp();
    cout<<"------------------\n";
    CA ob3(ob1);
    CA ob4(ob1);
    CA ob5(ob1);

    CA ob6(ob2);

    ob5.disp();
    ob6.disp();
    cout<<"------------------\n";
    ob1 = ob2;
    cout<<"------------------\n";
    ob1.disp();
    ob2.disp();
}
