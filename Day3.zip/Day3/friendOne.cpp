/*
* Intro to friend function...
*/

#include<iostream>
using std::cout;

class Simple{
    int x;
    int y;

    Simple& fun(){
        cout<<"fun()\n";
        x=10;y=20;
        return *this;
    }
    Simple& funOne(){
        cout<<"funOne()\n";
        x=y=20;
        return *this;
    }
    Simple &fun(int a){
        cout<<"fun(int)\n";
        x=a; y=a+20;
        return *this;
    }
    friend int main();//ease of access
};

int main(){//main is not a member...
    Simple obj;//creating...
    obj.fun();//
    obj.fun(10);
    obj.funOne();
}
