#include<iostream>
#include<cstdio>
using namespace std;

class File; //forward declaration

class FileHelper{
    File &fref;
    char buff[1];
    int index;
public:
    FileHelper(File &f, int index):fref(f), index(index){}

    FileHelper& operator=(char c);

    operator char();
};

class File{
    FILE *fptr;
public:
    File(const char *name){
        fptr = fopen(name,"w+");
    }
    ~File(){
        fclose(fptr);
    }

    FileHelper operator[](int index){
        return FileHelper(*this, index);
    }

    friend class FileHelper;
};

FileHelper& FileHelper::operator=(char c){
        fseek(fref.fptr, index, 0);
        fputc(c,fref.fptr);
        return *this;
    }

FileHelper::operator char(){
   fseek(fref.fptr, index, 0);
   buff[0] = fgetc(fref.fptr);
   return buff[0];
}

int main(){
    File obj("name.txt");
    obj[0]='1';//writing
    for (int cnt=0;cnt<26;cnt++)
        obj[cnt+1] = 'A' + cnt;

    char c = obj[3];//reading
    for (int cnt=0;cnt<27;cnt++)
        cout<<"C: "<<obj[cnt]<<"\n";
}



