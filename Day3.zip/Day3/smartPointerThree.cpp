#include <iostream>
using std::cout;

class CA{
    int *ptr;
public:
    CA(int x=0):ptr(new int(x)) {}
    CA(const CA &par):ptr(par.ptr){
        //Transferring the Ownership
        (const_cast<CA &> (par)).ptr = 0;//nullify
        //par.ptr = 0;//assign null
    }
    ~CA(){delete ptr;}
    void disp(){
        cout<<"Ptr: "<<ptr;
        if (ptr)
            cout<<"\t: *ptr: "<<*ptr<<'\n';
        else
            cout<<"\t:  ptr: null\n";
    }
};

int main(){
    CA ob1=10;
    CA ob2;
    ob1.disp();
    ob2.disp();
    {
        CA ob3 = ob1;//giving up owner-ship
        ob3.disp();
    }
    ob1.disp();//no-error
}






