/*
*
*/
#include <iostream>
using std::cout;

class CComplex{
    double _real;
    double _imag;
public:
    CComplex():_real(0.0), _imag(0.0){}
    CComplex(double real, double imag):_real(real), _imag(imag){}

    friend std::ostream& operator<<(std::ostream &out, CComplex &obj){
        out<<obj._real<<(obj._imag>=0.0?"+": "") << obj._imag<<"i" ;
        return out;
    }
};
void Line(std::ostream &out){
    out<<"-----------------------------------\n";
}
int main(){
    CComplex c1;
    CComplex c2(10,30);
    CComplex c3(12,-24);
    operator<<(cout,c1);cout<<"\n";
    operator<<(cout,c2);cout<<"\n";
    operator<<(cout,c3);cout<<"\n";
    Line(cout);
    cout<<"C1: "<<c1<<"End of C1\n";
    cout<<c2<<"\n";
    cout<<c3<<"\n";
    //cout<<c1<<c2<<c3<<'\n';
    Line(cout);
}




