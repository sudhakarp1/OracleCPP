/*
*
*/
#include <iostream>
using namespace std;

class Port{//smart Array
    int port[3];
public:
    Port(){
        port[0] = 8080;
        port[1] = 22;
        port[2] = 25;
    }
    class Helper{//Lazy ...
        Port &ptr;
        int index;
    public:
        Helper(Port &ptr, int index):ptr(ptr), index(index){}
        operator int(){//reading
            return ptr.port[index];
        }
        Helper& operator=(int val){//writing...
            ptr.port[index] = val;
            return *this;
        }

        Helper& operator=(Helper par){//read & write
            ptr.port[index] = par.ptr.port[par.index];
        }

    };

    Helper operator[](int index){
        return Helper(*this, index);
    }

    friend ostream & operator<<(ostream &out, Port &par){
        for(int i=0;i<3;i++){
            out<<"port["<<i<<"]="<<par.port[i]<<"\n";
        }
        return out;
    }
};

int main(){
    Port port;//8080, 22, 25
    int x = port[2]; //Reading ...//port.operator[](2)
    cout<<"X:" <<x<<"\n";
    port[1] = 8000; //writing...
    port[0] = port[1] ;// both read and write...
    cout<<port<<"\n";
}






