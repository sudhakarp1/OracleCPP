#include <iostream>
using std::cout;

class CA{
    int *ptr;
public:
    CA(int x=0):ptr(new int(x)) {}
    ~CA(){delete ptr;}
    void disp(){cout<<"Ptr: "<<ptr<<"\t: *ptr: "<<*ptr<<'\n';}
};

int main(){
    CA ob1=10;
    CA ob2;
    ob1.disp();
    ob2.disp();
    {
        CA ob3 = ob1;//shallow copy
        ob3.disp();
    }
    ob1.disp();//dangling pointer
}





