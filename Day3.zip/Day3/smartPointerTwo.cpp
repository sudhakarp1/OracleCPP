#include <iostream>
using std::cout;

class CA{
    int *ptr;
public:
    CA(int x=0):ptr(new int(x)) {}
    CA(const CA &par):ptr(par.ptr){//Transferring the Ownership
        (const_cast<CA &> (par)).ptr = 0;//nullify
    }

    CA& operator=(const CA &rhs){//transfer ownership
        int *temp = ptr;//copy & swap
        ptr = rhs.ptr;
        (const_cast<CA &>(rhs)).ptr = temp;

        return *this;
    }

    ~CA(){delete ptr;}
    void disp(){
        cout<<"Ptr: "<<ptr;
        if (ptr)
            cout<<"\t: *ptr: "<<*ptr<<'\n';
        else
            cout<<"\t:  ptr: null\n";
    }
};

int main(){
    CA ob1=10;
    CA ob2;
    ob1.disp();
    ob2.disp();
    cout<<"------------------\n";
    ob1=ob2;
    ob1.disp();
    ob2.disp();
    cout<<"------------------\n";
}






