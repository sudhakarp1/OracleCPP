/*
* Intro to this pointer
*/

class Simple{
    int x;
    int y;
public:
    void fun(){ x=10;y=20;}
    void funOne(){x=y=20;}
    void fun(int a){x=a; y=a+20;}
};

int main(){
    Simple obj;
    obj.fun(); // fun(&obj) -->
    obj.fun(10);//fun(&obj, 10)
    obj.funOne();//funOne(&obj)
}


