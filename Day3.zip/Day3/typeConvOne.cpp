/*
*built-in  to  UDT
*/
#include <iostream>
using std::cout;

class CA{
    int data;
public:
    explicit CA(int x):data(x){cout<<"CA(int)...\n";}
    CA():data(0){cout<<"CA()...\n";}
    void disp(){cout<<"CA::disp() "<<data<<"\n";}
    CA& operator=(int x){
        data = x;
        return *this;
    }
    //type conversion operator
    operator int(){return data;}
    //will be called when you assign to int
};

int main(){
    CA obj(10);//explicit calling
    obj =100; //obj = operator=(100)
    obj.disp();
    obj = 200;//obj = operator=(200)
    obj.disp();

    int i = obj; //i = obj.operator int()
    cout<<"i: "<<i<<"\n";
}




