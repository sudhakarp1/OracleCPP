/*
*
*/
#include <iostream>
using std::cout;

class CComplex{
    double _real;
    double _imag;
public:
    CComplex():_real(0.0), _imag(0.0){}
    CComplex(double real, double imag):_real(real), _imag(imag){}

    void disp(std::ostream &out){
        out<<_real<<(_imag>=0.0?"+": "") << _imag<<"i\n" ;
    }
};

void Line(std::ostream &out){
    out<<"-----------------------------------\n";
}

int main(){
    CComplex c1;
    CComplex c2(10,30);
    CComplex c3(12,-24);
    c1.disp(cout);
    c2.disp(cout);
    c3.disp(cout);
    Line(cout);
}



