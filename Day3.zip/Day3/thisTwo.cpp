/*
* Intro to this pointer
*/
#include<iostream>
using std::cout;

class Simple{
    int x;
    int y;
public:
    Simple& fun(){
        cout<<"fun()\n";
        x=10;y=20;
        return *this;
    }
    Simple& funOne(){
        cout<<"funOne()\n";
        x=y=20;
        return *this;
    }
    Simple &fun(int a){
        cout<<"fun(int)\n";
        x=a; y=a+20;
        return *this;
    }
};

int main(){
    Simple obj;
    obj.fun().fun(10).funOne();//cascading call
    /*
       _1 = Simple::fun (&obj);
        _2 = Simple::fun (_1, 10);
        Simple::funOne (_2);
    */
}



