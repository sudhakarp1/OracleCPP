/**
** C++ Style
**/
#include<iostream>
using std::cout;

class Calc{
public:
    int operator()(Calc &Reff, int x,int y){
           return Reff(x,y);
    }
    virtual int operator()(int,int){ return 0;}
};

class Add:public Calc{
public:
    int operator() (int x,int y){ //function operator
        return x+y; //func + tor --> functor or functional objects
    }
};

class Sub:public Calc{
public:
    int operator() (int x,int y){ //function operator
        return x-y; //func + tor --> functor or functional objects
    }
};

int main(){
    Add add;//object behaving like a function..
    Calc calc;
    Sub sub;
    cout<<"Add: "<<calc(add,10,20)<<"\n";
    cout<<"Sub: "<<calc(sub,100,20)<<"\n";
}

