/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <iostream>
using std::cout;

void fun();
int main(){
    void (*fptr)() = &fun ;//fun;
    (*fptr)();//fptr();
}
void fun(){
    cout<<"fun()...\n";
}


