/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <iostream>
using std::cout;

void fun();
typedef void (*fptr)();
int main(){
    fptr ptr = &fun ;//fun;
    ptr();//fptr();
}
void fun(){
    cout<<"fun()...\n";
}



