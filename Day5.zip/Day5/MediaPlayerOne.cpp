#include <iostream>
#include <string>
using namespace std;

struct MediaPlayer{
    virtual void play()=0;
    virtual void pause()=0;

    static MediaPlayer* createObjects(string );
};

struct AudioPlayer:MediaPlayer{
    virtual void minimize(){cout<<"Audio::Minimize\n";}
};

class VideoPlayer:public MediaPlayer{
    virtual void fullScreen(){cout<<"Video::FullScreen\n";}
};
class MP3:public AudioPlayer{
    void play(){ cout<<"MP3 playing...\n"; }
    void pause(){ cout<<"MP3 Paused...\n"; }
};

class AAC:public AudioPlayer{
    void play(){ cout<<"AAC playing...\n"; }
    void pause(){ cout<<"AAC Paused...\n"; }
};

class MP4:public VideoPlayer{
    void play(){ cout<<"MP4 playing...\n"; }
    void pause(){ cout<<"MP4 Paused...\n"; }
};
class AVI:public VideoPlayer{
    void play(){ cout<<"AVI playing...\n"; }
    void pause(){ cout<<"AVI Paused...\n"; }
};


 MediaPlayer* MediaPlayer::createObjects(string type){
    if (type == "MP3") return new MP3();
    if (type == "AAC") return new AAC();
    if (type == "MP4") return new MP4();
    if (type == "AVI") return new AVI();
}//Factory method


int main(){
    MediaPlayer *ptr = MediaPlayer::createObjects("MP4");
    ptr->play();
    ptr->pause();
}
