/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <iostream>
using std::cout;

int Add(int ,int);
int Sub(int ,int);
int Div(int ,int);
int Mul(int ,int);
int Mod(int ,int);

int calculate(int (*)(int,int), int, int);//call back

int main(){
    cout<<"Add: "<<calculate(Add,10,20)<<"\n";
    cout<<"Sub: "<<calculate(Sub,100,20)<<"\n";
    cout<<"Div: "<<calculate(Div,10,3)<<"\n";
    cout<<"Mod: "<<calculate(Mod,100,15)<<"\n";
    cout<<"Mult: "<<calculate(Mul,10,20)<<"\n";
}
int calculate(int (*ptr)(int,int), int x, int y){//call back
    return ptr(x,y); //performing the call back
}

int Add(int x, int y){
    return x+y;
}

int Sub(int x, int y){
    return x-y;
}
int Div(int x, int y){
    return x/y;
}
int Mul(int x, int y){
    return x*y;
}
int Mod(int x, int y){
    return x%y;
}





