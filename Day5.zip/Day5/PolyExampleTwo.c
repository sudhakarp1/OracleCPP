#include <iostream>
using std::cout;

struct DB{
    void openDB(){cout<<"DB::OpenDB()...\n" ;}
    void closeDB(){cout<<"DB::CloseDB()...\n" ;}
};

class Account{
    DB dbObj;
protected:
    Account(){}
    virtual void ActualJob()=0;
public:
    void DoJob(){
        dbObj.openDB();
        ActualJob();
        dbObj.closeDB();
        cout<<"---------------------------\n";
    }
};

class SavingsAccount:public Account{
protected:
    void ActualJob(){
        cout<<"Withdrawing from Savings...\n";
    }
};


class CreditCardAccount:public Account{
protected:
    void ActualJob(){
        cout<<"Withdrawing from CreditCard...\n";
    }
};

int main(){
    SavingsAccount sa;
    sa.DoJob();

    CreditCardAccount ca;
    ca.DoJob();
}
