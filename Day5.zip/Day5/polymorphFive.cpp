/**
*** Polymorphism in C++
**/
#include<iostream>
using std::cout;

struct Base{
    void funOne(){cout<<"Base::funOne()\n";}
    virtual void funTwo(){cout<<"Base::funTwo()\n";}
    operator Base*(){ return this;    }
};

struct Derived:Base{
    void funOne(){cout<<"Derived::funOne()\n";}
    void funTwo(){cout<<"Derived::funTwo()\n";}
};

void Caller(Base *bPtr){
    cout<<"Pointer: \n";
    bPtr->funOne();
    bPtr->funTwo();
    cout<<"------------\n";
}

int main(){
    Base bObj;
    Derived dObj;
    cout<<"------------Statement #1----------------\n";
    Caller(&bObj);
    Caller(bObj); //Caller(bObj.operator Base*())
    cout<<"----------Statement #2------------------\n";
    Caller(&dObj);
    Caller(dObj);//Caller(dObj.operator Base*())
}

