/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <iostream>
using std::cout;

void fun();
typedef void (*FPTR)();

int main(){
    FPTR ptr = &fun ;
    ptr();
}
void fun(){
    cout<<"fun()...\n";
}



