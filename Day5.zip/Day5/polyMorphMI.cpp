/***
*** Exhibiting Polymorphic behaviour in a Multiple inheritance
**/
#include <iostream>
using namespace std;

struct FileSystem{
    virtual void read()=0;
    virtual void write()=0 ;
};

struct Networking{
    virtual void read()=0;
    virtual void write()=0 ;
};

struct dummyFileSystem:FileSystem{
    virtual void readFS()=0;
    virtual void writeFS()=0;
    void read(){readFS(); }
    void write(){writeFS(); }
};

struct dummyNetworking:Networking{
    virtual void readNet()=0;
    virtual void writeNet()=0;
    void read(){readNet(); }
    void write(){writeNet(); }
};

struct Streaming:dummyFileSystem, dummyNetworking{
    void readFS(){cout<<"Streaming ...read() FileSystem\n";}
    void writeFS(){cout<<"Streaming ...write() FileSystem\n";}

    void readNet(){cout<<"Streaming ...read() Networking\n";}
    void writeNet(){cout<<"Streaming ...write() Networking\n";}
};


void downloadHere(Networking &net){
    cout<<"Downloading ...\n";
    net.read();
    FileSystem &fs = dynamic_cast<FileSystem &>(net);
    fs.write();
    cout<<"----------------------------\n";
}

void uploadHere(FileSystem &fs){
    cout<<"UP-Loading ...\n";
    fs.read();
    Networking &net = dynamic_cast<Networking &>(fs);
    net.write();
    cout<<"----------------------------\n";
}

int main(){
    Streaming obj;
    downloadHere(obj);
    uploadHere(obj);
}

