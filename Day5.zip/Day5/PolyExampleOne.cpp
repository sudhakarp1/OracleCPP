#include<iostream>
using std::cout;

class Network{//Abstract class
protected:
    bool isOn;
public:
    virtual void send()=0;
    virtual void recv()=0;
    bool check(){return isOn; }
    virtual ~Network(){}
};

class Ethernet:public Network{//concrete
public:
    void send(){cout<<"Ethernet::send()\n";}
    void recv(){cout<<"Ethernet::recv()\n";}
    Ethernet(bool val=false){
        isOn=val;
    }
};

void netTransciever(Network &ref){
    if (ref.check()){
        ref.send();
        ref.recv();
    }
}

class Wifi:public Network{
public:
    void send(){cout<<"Wifi::send()\n";}
    void recv(){cout<<"Wifi::recv()\n";}
    Wifi(bool val=false){
        isOn=val;
    }
};
int main(){
    Wifi obj(true);
    netTransciever(obj);
}
