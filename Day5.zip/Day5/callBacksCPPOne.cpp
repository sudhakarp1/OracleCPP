/**
** C++ Style
**/
#include<iostream>
using std::cout;


class Add{
public:
    int operator() (int x,int y){ //function operator
        return x+y; //func + tor --> functor or functional objects
    }
};


int main(){
    Add add;//object behaving like a function..

    cout<<"Add: "<<add(10,20))<<"\n";

}

