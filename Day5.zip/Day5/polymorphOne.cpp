/**
*** Polymorphism in C++
**/
#include<iostream>
using std::cout;

struct Base{
    void funOne(){cout<<"Base::funOne()\n";}
    virtual void funTwo(){cout<<"Base::funTwo()\n";}
};

struct Derived:Base{
    void funOne(){cout<<"Derived::funOne()\n";}
    void funTwo(){cout<<"Derived::funTwo()\n";}
};

int main(){
    Base bObj;
    Derived dObj;
    bObj.funOne(); bObj.funTwo();
    dObj.funOne(); dObj.funTwo();
}
