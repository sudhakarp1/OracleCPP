/**
*** Polymorphism in C++
**/
#include<iostream>
using std::cout;

struct Base{
    void funOne(){cout<<"Base::funOne()\n";}
    virtual void funTwo(){cout<<"Base::funTwo()\n";}
};

struct Derived:Base{
    void funOne(){cout<<"Derived::funOne()\n";}
    void funTwo(){cout<<"Derived::funTwo()\n";}
};

void Caller(Base *bPtr){
    cout<<"Pointer: \n";
    bPtr->funOne();
    bPtr->funTwo();
    cout<<"------------\n";
}
void Caller(Base &bRef){
    cout<<"Reference: \n";
    bRef.funOne();
    bRef.funTwo();
    cout<<"------------\n";
}

int main(){
    Base bObj;
    Derived dObj;
    cout<<"------------Statement #1----------------\n";
    Caller(&bObj);
    Caller(bObj);
    cout<<"----------Statement #2------------------\n";
    Caller(&dObj);
    Caller(dObj);
}
