/**
** C++ Style
**/
#include<iostream>
using std::cout;

class Add{
public:
    int operator() (int x,int y){ //function operator
        return x+y; //func + tor --> functor or functional objects
    }
};
class Sub{
public:
    int operator() (int x,int y){ //function operator
        return x-y; //func + tor --> functor or functional objects
    }
};
class Mul{
public:
    int operator() (int x,int y){ //function operator
        return x*y; //func + tor --> functor or functional objects
    }
};
int main(){
    Add add; Sub sub; Mul mul;
    cout<<"Add: "<<add(10,20)<<"\n";
    cout<<"Sub: "<<sub(10,20)<<"\n";
    cout<<"Mult: "<<mul(10,20)<<"\n";
}

