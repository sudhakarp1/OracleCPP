/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <stdio.h>

int Add(int ,int);
int Sub(int ,int);
int Div(int ,int);
int Mul(int ,int);
int Mod(int ,int);

typedef int (*FPTR)(int,int);

int main(){
    FPTR ptr = &Add ;
    printf("Add: %d\t%p\n",ptr(10,20),ptr);

    ptr = &Sub ;
    printf("Sub: %d\t%p\n",ptr(100,20),ptr);

    ptr = &Mul ;
    printf("Mul: %d\t%p\n",ptr(5,3),ptr);
}
int Add(int x, int y){
    return x+y;
}

int Sub(int x, int y){
    return x-y;
}
int Div(int x, int y){
    return x/y;
}
int Mul(int x, int y){
    return x*y;
}
int Mod(int x, int y){
    return x%y;
}



