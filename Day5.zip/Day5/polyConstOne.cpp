/**
*** Polymorphism in C++
**/
#include<iostream>
using std::cout;

struct Base{
    Base(){funTwo();}
    void funOne(){ funTwo();}
    virtual void funTwo(){cout<<"Base::funTwo()\n";}
    ~Base(){funTwo();}
};
struct Derived:Base{
    Derived(){funTwo();}
    void funTwo(){cout<<"Derived::funTwo()\n";}
    ~Derived(){funTwo();}
};
int main(){
    Derived dObj;
    cout<<"--------------------------------\n";
    dObj.funOne();
    cout<<"--------------------------------\n";
}


