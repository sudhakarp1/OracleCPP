#include <iostream>
#include <string>
#include <map>

using namespace std;

struct MediaPlayer{
    virtual void play()=0;
    virtual void pause()=0;

    static map<string ,MediaPlayer *> table;
    static MediaPlayer* createObjects(string type){
        return table[type];
    }
};

struct AudioPlayer:MediaPlayer{
    virtual void minimize(){cout<<"Audio::Minimize\n";}
};

class VideoPlayer:public MediaPlayer{
    virtual void fullScreen(){cout<<"Video::FullScreen\n";}
};
class MP3:public AudioPlayer{
    void play(){ cout<<"MP3 playing...\n"; }
    void pause(){ cout<<"MP3 Paused...\n"; }
    struct Reg{
        Reg(){
            table["MP3"] = new MP3();
        }
    };
    static Reg reg; // declarations only
};

class AAC:public AudioPlayer{
    void play(){ cout<<"AAC playing...\n"; }
    void pause(){ cout<<"AAC Paused...\n"; }

    struct Reg{
        Reg(){
            table["AAC"] = new AAC();
        }
    };
    static Reg reg; // declarations only
};

class MP4:public VideoPlayer{
    void play(){ cout<<"MP4 playing...\n"; }
    void pause(){ cout<<"MP4 Paused...\n"; }

    struct Reg{
        Reg(){
            table["MP4"] = new MP4();
        }
    };
    static Reg reg; // declarations only
};
class AVI:public VideoPlayer{
    void play(){ cout<<"AVI playing...\n"; }
    void pause(){ cout<<"AVI Paused...\n"; }
    struct Reg{
        Reg(){
            table["AVI"] = new AVI();
        }
    };
    static Reg reg; // declarations only
};
map<string , MediaPlayer *> MediaPlayer::table;
MP3::Reg MP3::reg;
AAC::Reg AAC::reg;
MP4::Reg MP4::reg;
AVI::Reg AVI::reg;


int main(){
    MediaPlayer *ptr = MediaPlayer::createObjects("MP4");
    ptr->play();
    ptr->pause();
}
