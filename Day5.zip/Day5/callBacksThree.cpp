/*
* fptr is declared as a pointer to a function taking no
* args returning nothing
*/

#include <iostream>
using std::cout;

int Add(int ,int);
int Sub(int ,int);
int Div(int ,int);
int Mul(int ,int);
int Mod(int ,int);

typedef int (*FPTR)(int,int);

int main(){
    FPTR ptr = &Add ;
    cout<<"Add: "<<ptr(10,20)<<"\t"<<ptr<<"\n";

    ptr = &Sub ;
    cout<<"Sub: "<<ptr(200,10)<<"\t"<<ptr<<"\n";

    ptr = &Mul ;
    cout<<"Mul: "<<ptr(5,3)<<"\t"<<ptr<<"\n";
}
int Add(int x, int y){
    return x+y;
}

int Sub(int x, int y){
    return x-y;
}
int Div(int x, int y){
    return x/y;
}
int Mul(int x, int y){
    return x*y;
}
int Mod(int x, int y){
    return x%y;
}



