/*
*Annotated Reference Manual
*/
#include <iostream>
using std::cout;

class DynArray{
	int *arr;
	int len;
public:
	DynArray():len(0),arr(0) {}
	DynArray(int len): len(len), arr(new int[len]) {}
	~DynArray(){
        if (len)
            delete [] arr;
        len=0;
	}

	void printArr(){
	    cout<<"Arr: ";
        for (int cnt=0;cnt<len;++cnt)
            cout<<arr[cnt]<<" ";
        cout<<"\n------------------------------\n";
	}
	int size(){return len; }
	void fillArr(int start=1){
        for (int cnt=0;cnt<len;++cnt)
            arr[cnt]= start + cnt;
	}

	void resize(int len){
        //implement the same here...
	}
};

int main(){
    DynArray arr;
    arr.printArr();
    arr.resize(10);
    arr.fillArr(11);
    arr.printArr()

    arr.resize(20);
    arr.printArr();
    arr.fillArr(101);
    arr.printArr();
}




