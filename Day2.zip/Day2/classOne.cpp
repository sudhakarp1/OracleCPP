/*
* Introduction to classes
*/

#include<iostream>
using std::cout;

class CA{
    //state/attributes --> private
    int x;
    int y;
public:
    //Behaviour/functionalities
    void setX(int val){ x = val;}
    void setY(int val){ y = val;}
    void setXY(int x,int y){
        this->x = x;
        this->y = y;
    }
    void dispState(){
        cout<<"X = "<<x<<'\n';
        cout<<"Y = "<<y<<'\n';
        cout<<"-------------------------\n";
    }

};

int main(){
    CA obj;
    obj.setX(1);
    obj.setY(2);
    obj.dispState();

    obj.setXY(10,20);
    obj.dispState();
}


