/*
* Introduction default constructor
*/

#include<iostream>
#include<string>
using std::cout;

class CA{//compiler synthesizes default constructor
    std::string  str;//data member
public:
    void fun(){
        cout<<"string : "<<str<<'\n';
    }
};

int main(){
    CA obj;
    obj.fun();
}

