/*
* Introduction default constructor
*/

#include<iostream>
using std::cout;

class Test{
public:
    Test(){}
    void fun(){cout<<"Test fun()...\n";}

};

class CA{//compiler synthesizes a default constructor
    Test obj;//data member
public:
    void fun(){
        obj.fun();
    }
};


int main(){
    CA obj;
    obj.fun();
}
