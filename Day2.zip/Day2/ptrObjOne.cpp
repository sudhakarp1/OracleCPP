#include <iostream>
using std::cout;
//MISRA C-->
class CA{
public:
    CA(){cout<<"Default ctor\n";}
    void fun(){cout<<"CA fun()...\n";}
    ~CA(){cout<<"Dtor\n";}
};

class CB{
public:
    void fun(){cout<<"CB fun..\n";}
};

int main(){
    CA *ptr;//pointer to an object is created
    CB obj;//object getting created

    ptr = (CA *)&obj;
    ((CB *)ptr)->fun();// ptr -> fun()... ptr is of CA
}



