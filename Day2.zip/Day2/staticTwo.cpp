/*
*
*/
#include <iostream>
using std::cout;

class Simple{
    int data;

    static Simple obj;//declaration..
public:
    Simple(int x=0):data(x) {}
    void disp(){cout<<"data: "<<data<<'\n';}

    static Simple &getObj(){return obj; }
};

int main(){
    Simple &ref = Simple::getObj();
    ref.disp();
}

Simple Simple::obj=100;//definition...



