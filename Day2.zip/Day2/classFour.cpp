/*
*
*/
#include <iostream>
using std::cout;

class CA{
public:
    void disp() const{
        cout<<"CA disp() const\n";
    }
};

int main(){
    const CA obj;
    obj.disp();
}
