#include <iostream>
using std::cout;
//MISRA C-->
class CA{
public:
    CA(){cout<<"Default ctor\n";}
    void fun(){cout<<"CA fun()...\n";}
    ~CA(){cout<<"Dtor\n";}
};

int main(){
    CA *ptr=new CA[5];
    //object of class CA is create in the heap
    (ptr+0)->fun();
    (ptr+1)->fun();
    (ptr+2)->fun();
    (ptr+3)->fun();
    (ptr+4)->fun();

    delete []ptr;
}



