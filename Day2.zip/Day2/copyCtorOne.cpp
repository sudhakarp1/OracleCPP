/*
*
*/
#include <iostream>
#include <string>
using std::cout;

class CA{
    int a;
    std::string ptr;
public:
    CA():a(10), ptr(std::string("Hello")){}
    /*CA(const CA &rhs){
        cout<<"CA Copy Ctor...\n";
    }*/
};
CA fun(CA);

int main(){
    CA obj;
    fun(obj);
}

CA&  fun(CA &obj){
    cout<<"Inside fun(CA obj)...\n";
    return obj;
}


