/*
*
*/
#include <iostream>
using std::cout;

class Simple{//Singleton class ---> a Class which has one object
    int data;
    static Simple *obj;//declaration..

    Simple(int x=0):data(x) { }
    Simple (const Simple &) ;//declared no definition
public:
    void disp(){cout<<"data: "<<data<<'\n';}
    static Simple &getObj(){
        if (0==obj)
            obj = new Simple(100);
        return *obj;
    }
};
int main(){
    Simple &ref = Simple::getObj();
    ref.disp();
    cout<<"Ref: "<<&ref<<'\n';

    Simple &refOne = Simple::getObj();
    refOne.disp();
    cout<<"RefOne: "<<&refOne<<'\n';
}

Simple* Simple::obj;//definition...

