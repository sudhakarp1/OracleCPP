/*
*
*/
#include <iostream>
using std::cout;

class Simple{
    int data;
    static Simple obj;//declaration..

    Simple(int x=0):data(x) { }

    Simple (const Simple &) ;//declared no definiton
public:
    void disp(){cout<<"data: "<<data<<'\n';}
    static Simple &getObj(){return obj; }
};
int main(){
    Simple &ref = Simple::getObj();
    ref.disp();

   // Simple NewObj = ref;
}
Simple Simple::obj=100;//definition...

