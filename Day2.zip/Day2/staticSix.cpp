/*
*
*/
#include<iostream>
using std::cout;

class Simple {//named constructor Idiom
    int data;
    Simple():data(0){}
    Simple(int x):data(x){}
public:
    void fun(){cout<<"data in Fun(): "<<data<<'\n';}

    static Simple *create(){return new Simple(); }
    static Simple *create(int x){return new Simple(x); }
};

int main(){
    Simple *ptr = Simple::create(10);
    ptr->fun();
}

