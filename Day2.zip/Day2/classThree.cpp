/*
* Intro to data members //
*/
#include <iostream>
using std::cout;

class CA{
    int a; //instance data member
    const int b; // constant instance DM
    mutable int c; // non-constant instance DM

    static int d;//class member
    static const int e ;//class member which is constant
public:
    CA():a(10), b(20),c(30){
        cout<<"CA Ctor\n";
    }
    //Mutator --> which can change object state
    void dispMutator(){
        a+=100;
        //b+=20; //will not work
        c+=100;
        cout<<"a: "<<a<<'\n';
        cout<<"b: "<<b<<'\n';
        cout<<"c: "<<c<<'\n';
        cout<<"d: "<<d<<'\n';
        cout<<"e: "<<e<<'\n';
        cout<<"---------------------------\n";
    }
    //Inspector (which cannot change object state)
    void dispInspector() const {
       // a+=10; //Error
        //b+=10; //error
        c+=100; //Valid
        d+=100;
        //e+=100;
        cout<<"a: "<<a<<'\n';
        cout<<"b: "<<b<<'\n';
        cout<<"c: "<<c<<'\n';
        cout<<"d: "<<d<<'\n';
        cout<<"e: "<<e<<'\n';
        cout<<"---------------------------\n";
    }

    static void statFun(){
        cout<<"d: "<<d<<'\n';
        cout<<"e: "<<e<<'\n';
        cout<<"---------------------------\n";
    }

    ~CA(){
        cout<<"CA Dtor \n";
    }
};
//static members must be initialize outside the class
//definition...
int CA::d = 1000;
const int CA::e = 2000;

int main(){
    const CA obj;
    //obj.dispMutator();
    obj.dispInspector();

    CA::statFun();
}






