

int main(){
    unsigned myInt;

    myInt = printf;

    myInt("Hello World\n...");

}
