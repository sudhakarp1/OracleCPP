/*
*CA(int par):a(par),b(par),c(par)
CA(int par):a(par),b(a),c(b)
CA(int par):b(a),c(b),a(par)
*/
#include <iostream>
using std::cout;

class CA{
    int a;
    int b;
    int c;
public:
    //CA(int a,int b,int c):b(b),c(c),a(a){}
    void disp(){
        cout<<"a: "<<a<<'\n';
        cout<<"b: "<<b<<'\n';
        cout<<"c: "<<c<<'\n';
        cout<<"--------------------------\n";
    }
};

int main(){
    CA obj;//(10,20,30);
    obj.disp();
}


