/*
*
*/
#include <iostream>
using std::cout;

class Simple{
    int data;
public:
    Simple(int x=0):data(x) {}
    void disp(){cout<<"data: "<<data<<'\n';}

    static Simple obj;//declaration..
};

int main(){
    Simple::obj.disp();
}

Simple Simple::obj=100;//definition...


