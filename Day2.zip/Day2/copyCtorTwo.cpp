/*
*Member-wise copy or shallow
*/
#include <iostream>
#include <cstdlib>

using std::cout;

class DynArray{
	int *arr;
	int len;
public:
	DynArray():len(0),arr(0) {}
	DynArray(int len): len(len), arr(new int[len]) {}

	DynArray(const DynArray& rhs){ //Deep Copy
        len = rhs.len;
        if (len){
            arr = new int[len];
            memcpy(arr, rhs.arr, len*sizeof(int));
        }
	}
	~DynArray(){
        if (len)
            delete [] arr;
        len=0;
	}

	void printArr(){
	    cout<<"Arr: "<<arr<<"\n";
        for (int cnt=0;cnt<len;++cnt)
            cout<<arr[cnt]<<" ";
        cout<<"\n------------------------------\n";
	}
	int size(){return len; }
	void fillArr(int start=1){
        for (int cnt=0;cnt<len;++cnt)
            arr[cnt]= start + cnt;
	}

	void resize(int len){
        //implement the same here...
	}
};


int main(){
    DynArray one(30);
    one.fillArr();
    one.printArr();
    {
        DynArray two=one;//User-Defined copy constructor
        two.printArr();
    }
    one.printArr();
}


