#include <iostream>
using std::cout;

class LinkedList{
    struct Node{ //local class
        int data;
        Node *next;

        Node(int x=0):data(x),next(0) {}
        void disp(){cout<<data<<" ";}
    }*head;

    void clearAll();//will be used in D'tor
    void copyNodes();//will be used in copy C'tor

public:
    LinkedList():head(0){}
    void insertNode(int data){
        Node *New =new Node(data);
        if (0==head)
            head = New;
        else{
            New->next = head;
            head = New;
        }
    }

    void disp(){
        Node *temp = head;
        cout<<"List: ";
        while(temp){
            temp->disp();
            temp = temp->next;
        }
        cout<<"\n";
    }

    void appendNode(int data){
        Node *New =new Node(data);
        if (0==head)
            head = New;
        else{
            Node *cnt;
            for (cnt = head; cnt->next!= 0 ;cnt=cnt->next)
                ;
            cnt->next = New;
        }
    }

    int countNodes(){
        int count=0;
        for (Node *cnt = head; cnt != 0 ;count++, cnt=cnt->next)
                ;
        return count;
    }

};

int main(){
    LinkedList one;
    for (int cnt=0;cnt<50;cnt++)
        one.appendNode(101+ cnt);

    one.disp();
    cout<<"Total Nodes: "<<one.countNodes()<<"\n";

    //LinkedList two = one;//copy constructor
    //Implement your logic to support the above operator
    //also provide destructor to delete all nodes...
}


