#include <iostream>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n";}
    void fun(){cout<<"CA fun()\n";}
    ~CA(){cout<<"CA D-tor \n";}
};

int main(){
    CA *cp = new CA(); //global function
        /* operator new()
        *  cp->CA::CA()
        */
    cp->fun();

    delete cp;
    /*
    * cp->CA::~CA()
    * operator delete()
    */
}


