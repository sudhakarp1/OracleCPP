#include <iostream>
#include <cstdlib>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n";}
    static void * operator new(size_t size){
        cout<<"operator new()\n";
        void *temp = malloc(size);
        return temp;
    }

    static void operator delete(void *ptr){
        cout<<"operator delete()\n";
        free(ptr);
    }

    void fun(){cout<<"CA fun()\n";}
    ~CA(){cout<<"CA D-tor \n";}
};

int main(){
    CA *cp = new CA(); //global function
        /* operator new()
        *  cp->CA::CA()
        */
    cp->fun();

    delete cp;
    /*
    * cp->CA::~CA()
    * operator delete()
    */
}



