#include <iostream>
using namespace std;


class CA{
    int data;
public:
    void funOne(){
        cout<<"CA::funOne()...\n";
    }
    virtual void funTwo(){
        cout<<"CA::funTwo()...\n";
    }

    virtual void funThree(){
        cout<<"CA::funThree()...\n";
    }
};

int main(){
    CA obj;
    typedef void (*FPTR)();
    cout<<"Size: "<<sizeof(obj)<<"\n";
    long *vptr = (long *)&obj;

    long *vtbl = (long *)*vptr;
    cout<<"VTBL: "<<vtbl<<"\n";

    ((FPTR)vtbl[0])();
    ((FPTR)vtbl[1])();
}

