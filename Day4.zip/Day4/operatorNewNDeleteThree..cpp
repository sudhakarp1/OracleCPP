#include <iostream>
#include <cstdlib>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n";}
    static void * operator new(size_t size){
        cout<<"operator new()\n";
        void *temp = malloc(size);
        return temp;
    }

    static void * operator new[](size_t size){
        cout<<"operator new[]...()\n";
        void *temp = malloc(size);
        return temp;
    }

    static void operator delete(void *ptr){
        cout<<"operator delete()\n";
        free(ptr);
    }

    static void operator delete[](void *ptr){
        cout<<"operator delete[]...()\n";
        free(ptr);
    }

    void fun(){cout<<"CA fun()\n";}
    ~CA(){cout<<"CA D-tor \n";}
};

class Pointer{ //Wrapping a pointer to class CA
    CA *ptr;

    static void * operator new(size_t size){
        return NULL;
    }
    static void * operator new[](size_t size){
        return NULL;
    }
    static void operator delete(void *ptr){
    }
    static void operator delete[](void *ptr){
    }
public:
    Pointer():ptr(new CA()){}
    CA *operator -> (){
        cout<<"operator ->() \n";
        return ptr;
    }
    CA& operator *(){cout<<"operator *() \n"; return *ptr; }
    ~Pointer(){ delete ptr;}
};

int main(){
   Pointer obj; //Pointer is working as smart-pointer
   obj->fun();
   (*obj).fun();
}


