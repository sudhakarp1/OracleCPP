#include <iostream>
#include <cstdlib>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n";}
    static void * operator new(size_t size){
        cout<<"operator new()\n";
        void *temp = malloc(size);
        return temp;
    }

    static void * operator new[](size_t size){
        cout<<"operator new[]...()\n";
        void *temp = malloc(size);
        return temp;
    }

    static void operator delete(void *ptr){
        cout<<"operator delete()\n";
        free(ptr);
    }

    static void operator delete[](void *ptr){
        cout<<"operator delete[]...()\n";
        free(ptr);
    }

    void fun(){cout<<"CA fun()\n";}
    ~CA(){cout<<"CA D-tor \n";}
};

int main(){
    CA *cp = new CA(); //global function
    cp->fun();
    delete cp;
    cout<<"----------------------------\n";

    cp = new CA[3];
    for(int cnt=0;cnt<3;cnt++)
        cp[cnt].fun();
    delete [] cp;
    cout<<"----------------------------\n";
}

