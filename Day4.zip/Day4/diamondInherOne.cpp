
#include <iostream>
using std::cout;

struct CBase{
    void someFun(){cout<<"CBase someFun()..\n";}
};
struct BaseOne:virtual CBase{
    int a;
    BaseOne(int x=0):a(x){}
    void fun(){cout<<"BaseOne..."<<a<<"\n";}
};
struct BaseTwo:virtual CBase{
    int b;
    BaseTwo(int x=0):b(x){}
    void fun(){cout<<"BaseTwo..."<<b<<"\n";}
};

struct Derived:BaseOne, BaseTwo{
    int c;
    Derived(int x=1,int y=2,int z=3):BaseOne(x),BaseTwo(y),c(z){}
    void fun(){cout<<"Derived..."<<a<<"\t"<<b<<"\t"<<c<<"\n";}
};

int main(){
    Derived dObj(100,200,300);
    dObj.fun();

    dObj.someFun();
}


