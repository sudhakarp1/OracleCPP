#include <iostream>
using namespace std;

class CA{
    int data;
public:
    void funOne(){
        cout<<"CA::funOne()...\n";
    }
    virtual void funTwo(){
        cout<<"CA::funTwo()...\n";
    }
    virtual void funThree(){
        cout<<"CA::funThree()...\n";
    }
};

int main(){
    CA obj;
    CA &ref = obj;
    CA *ptr = &obj;

    obj.funOne();//obj.CA::funOne()
    obj.funTwo();//obj.CA::funTwo()
    obj.funThree();//obj.CA::funThree()
    cout<<"----------------------------------\n";
    ref.funOne();//ref.CA::funOne()
    ref.funTwo();//ref.vptr->vtbl[0]()
    ref.funThree();//ref.vptr->vtbl[1]()
    cout<<"----------------------------------\n";
    ptr->funOne();//ptr->CA::fun()
    ptr->funTwo();//ptr->vptr->vtbl[0]()
    ptr->funThree();//ptr->vptr->vtbl[1]()
    cout<<"----------------------------------\n";
}


