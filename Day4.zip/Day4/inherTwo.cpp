#include <iostream>
using std::cout;

struct BaseOne{
    BaseOne(){cout<<"BaseOne()...\n";}
    BaseOne(int){cout<<"BaseOne(int)...\n";}
    ~BaseOne(){cout<<"~BaseOne()...\n";}
};

struct BaseTwo{
    BaseTwo(){cout<<"BaseTwo()...\n";}
    BaseTwo(int){cout<<"BaseTwo(int)...\n";}
    ~BaseTwo(){cout<<"~BaseTwo()...\n";}
};

struct CA{
    CA(){cout<<"CA()...\n";}
    ~CA(){cout<<"~CA()...\n";}
};

struct CB{
    CB(){cout<<"CB()...\n";}
    ~CB(){cout<<"~CB()...\n";}
};

struct Derived:BaseTwo, BaseOne{
    CA obj1;
    CB obj2;

    Derived(){cout<<"Derived()...\n";}
    Derived(int x):BaseOne(x),BaseTwo(x){cout<<"Derived(int)...\n";}
    ~Derived(){cout<<"~Derived()...\n";}
};

int main(){
    Derived obj(10);
    cout<<"-----------------------------------\n";
    BaseOne bObj(20);

    bObj = obj; // object slicing...
    //Derived class is a Base class
    //obj = bObj; //
}

