

#include <iostream>
using std::cout;

struct CBase{
    //CBase(){cout<<"CBase()..\n";}
};
struct BaseOne: CBase{
    int a;
    //BaseOne(int x=0):a(x){cout<<"BaseOne()...\n";}
    void fun(){cout<<"BaseOne..."<<a<<"\n";}
};
struct BaseTwo:virtual CBase{
    int b;
    //BaseTwo(int x=0):b(x){cout<<"BaseTwo()...\n";}
    void fun(){cout<<"BaseTwo..."<<b<<"\n";}
};

struct Derived:BaseOne, BaseTwo{
    int c;
    /*Derived(int x=1,int y=2,int z=3):BaseOne(x),BaseTwo(y),c(z){
        cout<<"Derived()...\n";
    }*/
    using BaseOne::fun;//vertical access
    //void fun(){cout<<"Derived..."<<a<<"\t"<<b<<"\t"<<c<<"\n";}
};

int main(){
    Derived dObj;
    dObj.fun();
}




