
#include <iostream>
using std::cout;


struct BaseOne{
    int a;
    BaseOne(int x=0):a(x){}
    void fun(){cout<<"BaseOne..."<<a<<"\n";}
};
struct BaseTwo{
    int b;
    BaseTwo(int x=0):b(x){}
    void fun(){cout<<"BaseTwo..."<<b<<"\n";}
};

struct Derived:BaseOne, BaseTwo{
    int c;
    //using BaseOne::fun;
    Derived(int x=1,int y=2,int z=3):BaseOne(x),BaseTwo(y),c(z){}
    void fun(){cout<<"Derived..."<<a<<"\t"<<b<<"\t"<<c<<"\n";}
};

int main(){
    Derived dObj(100,200,300);
    dObj.fun();
    dObj.BaseTwo::fun();
    dObj.BaseOne::fun();
}


