#include <iostream>
#include <cstdlib>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n"; }
    void fun(){cout<<"CA fun()\n";}
    CA* operator ->(){cout<<"CA operator-->()\n";return this;}
    ~CA(){cout<<"CA D-tor \n";}
};
class Wrapper{
    CA obj;
public:
    Wrapper(){cout<<"Wrapper()\n";}
    ~Wrapper(){cout<<"~Wrapper()\n";}
    CA* operator ->(){cout<<"Wrapper operator-->()\n"; return &obj;}
    CA& fun(){cout<<"Wrapper fun()\n"; return obj;}
};
int main(){
    Wrapper w;
    cout<<"----------------------------------\n";
    w.fun()->fun();
    cout<<"----------------------------------\n";
}
//


