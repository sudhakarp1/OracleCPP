#include <iostream>
#include <cstdlib>
using std::cout;

class CA{
    bool isOnHeap;
    static int count;
public:
    void *operator new(size_t size){
        count=1;
        CA* ob = (CA *) malloc(size);
        return ob;
    }
    void *operator new[](size_t size){
        count=size/sizeof(CA);
        CA* ob = (CA *) malloc(size);
        return ob;
    }

    CA(){
        count--;
        if(count>=0)
            isOnHeap=true;
        else
            isOnHeap=false;
    }

    void objectLocation(){
        if(isOnHeap)
            cout<<"I am on Heap\n";
        else
            cout<<"I am (Not) on Heap\n";
    }
};

int CA::count;

int main(){
    CA obj1;
    CA *ptr1 = new CA();
    CA obj2;
    CA *ptr2 = new CA[3];
    obj1.objectLocation();
    obj2.objectLocation();
    cout<<"----------------------------------\n";
    ptr1->objectLocation();
    ptr2[0].objectLocation();
    ptr2[1].objectLocation();
    ptr2[2].objectLocation();
    cout<<"----------------------------------\n";
}
//



