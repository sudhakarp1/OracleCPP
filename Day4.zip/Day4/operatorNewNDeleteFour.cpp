#include <iostream>
#include <cstdlib>
using std::cout;

struct CA{
    CA(){cout<<"CA C-tor \n"; throw std::runtime_error("");}
    ~CA(){cout<<"CA D-tor \n";}

    void *operator new (size_t size, bool b){
        cout<<"operator new "<<b<<"\n";
        void *temp = malloc(size);
        return temp;
    }

    void operator delete (void *ptr, bool b){
        cout<<"operator delete "<<b<<"\n";
        free(ptr);
    }
};

int main(){
    try{
        CA *cptr = new (false) CA();
        cout<<"Some statement...\n";
    //    delete cptr;
    }catch(...){
        cout<<"At the end...\n";
    }
}

