#include <iostream>
using namespace std;

class CA{
    int data;
public:
    void funOne(){
        cout<<"CA::funOne()...\n";
    }
    virtual void funTwo(){
        cout<<"CA::funTwo()...\n";
    }

    virtual void funThree(){
        cout<<"CA::funThree()...\n";
    }
};

int main(){
    CA obj;
    CA obj1;
    typedef void (*FPTR)();
    cout<<"Size: "<<sizeof(obj)<<"\n";
    long *vptr = (long *)&obj;
    cout<<"VPTR: "<<vptr<<"\t"<<(long *)*vptr<<"\n";
    vptr = (long *)&obj1;
    cout<<"VPTR: "<<vptr<<"\t"<<(long *)*vptr<<"\n";

    cout<<"-------------------------------------\n";
    long *vtbl = (long *)*vptr;
    cout<<"VTBL: "<<vtbl<<"\n";

}

