#include<iostream>
using std::cout;

class Base{
    int a;//private data
protected:
    int b; // protected data
public:
    int c;
    Base():a(1),b(2),c(3){}
    void fun(){
        cout<<"Base::fun()...\n";
        cout<<"a: "<<a<<"\n";
        cout<<"b: "<<b<<"\n";
        cout<<"c: "<<c<<"\n";
        cout<<"-----------------------------\n";
    }

    friend class Derived;
};
class Derived:public Base{
public:
    void fun(){
        a=10;
        b=20;//protected
        c=30;//public
        cout<<"Derived fun()...\n";
        cout<<"a: "<<a<<"\n";
        cout<<"b: "<<b<<"\n";
        cout<<"c: "<<c<<"\n";
        cout<<"-----------------------------\n";
    }
};

int main(){
    Derived obj;
    obj.fun();
    obj.c = 300;
    obj.fun();
}

