#include <iostream>
using std::cout;


struct BaseOne{
    int a;
    BaseOne(int x=0):a(x){}
    void fun(){cout<<"BaseOne..."<<a<<"\n";}
};
struct BaseTwo:BaseOne{
    int b;
    BaseTwo(int x=0,int y=0):b(y),BaseOne(x){}
    void fun(){cout<<"BaseTwo..."<<b<<"\n";}
};

struct Derived:BaseTwo{
    int c;
    Derived(int x=1,int y=2,int z=3):BaseTwo(x,y),c(z){}
    void fun(){cout<<"Derived..."<<a<<"\t"<<b<<"\t"<<c<<"\n";}
};

int main(){
    cout<<"Size of BaseOne: "<<sizeof(BaseOne)<<"\n";
    cout<<"Size of BaseTwo: "<<sizeof(BaseTwo)<<"\n";
    cout<<"Size of Derived: "<<sizeof(Derived)<<"\n";
    Derived dObj(100,200,300);
    dObj.fun();

    BaseTwo b2Obj = dObj;//object slicing..
    b2Obj.fun();

    BaseOne b1Obj = dObj;
    b1Obj.fun();
}


