#include<iostream>
using namespace std;

void fun(int);//--->__Z3funi
void fun(float);//--->__Z3funf

int main(){
    fun(20.234f);//will call line#7
}
void fun(int){
    cout<<"void fun(int)\n";
}
void fun(float){
    cout<<"void fun(float)\n";
}


