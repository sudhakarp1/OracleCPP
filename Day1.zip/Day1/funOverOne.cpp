#include<iostream>
using namespace std;

extern "C" void testHere(){}
void fun(); //---__Z3funv
void fun(int);//--->__Z3funi
void fun(float);//--->__Z3funf
void fun(double);//--->__Z3fund

int main(){
    fun();//will call line#4
    fun(10);//will call line#5
    fun(20.234);//will call line#7
}

void fun(){
    cout<<"void fun()\n";
}
void fun(int){
    cout<<"void fun(int)\n";
}
void fun(float){
    cout<<"void fun(float)\n";
}
void fun(double){
    cout<<"void fun(double)\n";
}

