/*
* Different types of variables Here...
*/
#include <iostream>
using std::cout;

int var=10, varOne; ////BSS, data
static int sVar=100,sVarOne;////BSS, data

void fun(int arg1, int arg2){//stack
    static int myVar=10000, mySVar; //BSS, data
    int locOne=10,locTwo=20;//stack
    {
        int  a=100, b=200;//stack
    }
}
int main(){
    int a=10,b=20;//stack
    fun(a,b);
    int *ptr; //stack variable
    ptr = new int(10); //Heap variable
}



