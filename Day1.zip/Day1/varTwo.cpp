#include <iostream>
using std::cout;

//
int main(){
    static int arr[1024]={1,2,3,4,5,7,8};
    arr[0]=0;
    cout<<arr[0]<<'\n';

}
