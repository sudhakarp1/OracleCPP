#include <iostream>
using namespace std;

int main(){
    cout << "Enter an Integer!" << endl;
    auto var = "Some string here"; //Post C++ 11 onwards...
    cout<<"The variable value is "<<var<<'\n'<<typeid(var).name()<<'\n';

    return 0;
}
