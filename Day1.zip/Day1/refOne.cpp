/*
* Referencing in C++
*/

#include <iostream>
using std::cout;

void change(int &); //lvalue references
void change(int &&); //rvalue references in modern C++
//var = 100;
int && fun();

int main(){
    int var=10;
    cout<<"Before..."<<var<<'\n';
    change(10);
    change(var);
    cout<<"After..."<<var<<'\n';
    int &&refHere = 10000;//fun();
    cout<<"Ref Here: "<<refHere<<'\n';
}
void change(int &&ref){//Only in modern C++
    cout<<"RVALUE..."<<ref<<'\n';
    ref+=100;
}
void change(int &ref){
    cout<<"LVALUE...\n";
    ref+=100;
}

int &&fun(){
    int x=100;
    cout<<"Hello...";
    return 100;
}






