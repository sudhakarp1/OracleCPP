//Each
#include <iostream>
using namespace std;

int main(){
    extern int var;

    cout<<"Global var: "<<var<<'\n';
}
