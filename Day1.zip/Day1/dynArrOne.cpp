#include<iostream>
#include<cstdlib>
using std::cout;
using std::cin;

namespace Mine{
    void allocNFill(int ,int );
    void printArr(){}

    class someClass{
    };
}

int main(){
    using namespace Mine;
    //using Mine::someClass;

    someClass obj;
    Mine::printArr();

    Mine::allocNFill(10,1);
    cin.get();

    allocNFill(100,1);
    cin.get();

    allocNFill(1000,1);
    cin.get();

    allocNFill(100000,1);
}

void Mine::allocNFill(int sze,int start){
    int *arr;
    arr = new int[sze]; //heap based memory allocation
    for (auto cnt=0;cnt<sze;cnt++)
        arr[cnt] = start+cnt;

    cout<<"Printing the Array: \n";
    for (auto cnt=0;cnt<sze;cnt++)
        cout<<arr[cnt]<<" ";
    cout<<'\n';

    delete []arr;//freeing the heap memory
}

